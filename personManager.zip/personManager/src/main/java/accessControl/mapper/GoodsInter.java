package accessControl.mapper;

import accessControl.pojo.Goods;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface GoodsInter {
    //插入一个物品
    int InsertGoods(Goods goods);
    //删除一个物品
    int DeleteGoods(@Param("goodsId")int goodsId);
    //更新一个物品
    int UpdateGoods(@Param("goods")Goods goods);
    //查询一个物品
    Goods SelectOne(@Param("goodsId")int goodsId);
    //查询所有物品
    List<Goods> SelectGoods();
}
