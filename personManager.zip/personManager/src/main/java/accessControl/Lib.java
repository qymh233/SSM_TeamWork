package accessControl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import accessControl.mapper.UserInter;
import accessControl.pojo.Users;

public class Lib {
	@Autowired
	UserInter userInter;
    public static void main(String[] args) {

    }
}
