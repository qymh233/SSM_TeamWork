//package Demo1;
//
//import accessControl.mapper.GoodsInter;
//import accessControl.pojo.Goods;
//import accessControl.pojo.Manager;
//import accessControl.pojo.Report;
//import accessControl.pojo.Users;
//import accessControl.service.AdminService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Collection;
//import java.util.Date;
//import java.util.List;
//import java.util.Map;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("classpath:spring.xml")
//public class AdminServiceTestDemo {
//    @Autowired
//    AdminService adminService;
//    Map<Integer,Integer> map;
//    @Test
//    public void Test1(){
//    	//登录测试
//    	Manager admin=new Manager();
//    	admin.setAdminId(1);
//    	admin.setAdminPW("123456");
//    	if(adminService.AdminLogin(admin)) {
//    		System.out.println("Login Success!");
//    	}
//    	else {
//    		System.out.println("Login Defeat!");
//		}
//    }
//    @Test
//    public void Test2(){
//    	//签到测试
//    	if(adminService.AdminSignIn("36.2")) {
//    		System.out.println("Signin Success!");
//    	}
//    	else {
//    		System.out.println("Signin Defeat!");
//		}
//    }
//
//    @Test
//    public void Test3(){
//    	//添加物品测试
//        Goods g=new Goods();
//        g.setGoodsId(6);
//        g.setGoodsInTime(new Date());
//        g.setGoodsName("地瓜");
//        g.setGoodsNum(20);
//        g.setGoodsSource("业主送的");
//        if(adminService.AddGoods(g)) {
//    		System.out.println("AddGoods Success!");
//    	}
//    	else {
//    		System.out.println("AddGoods Defeat!");
//		}
//    }
//    @Test
//    public void Test4(){
//    	//删除物品测试
//    	if(adminService.DeleteGoods(5)) {
//    		System.out.println("DeleteGoods Success!");
//    	}
//    	else {
//    		System.out.println("DeleteGoods Defeat!");
//		}
//    }
//    @Test
//    public void Test5() throws ParseException{
//    	//修改物品测试
//		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
//    	Date date = dateformat.parse("2020/5/9");
//    	System.out.println(dateformat.format(date));
//        Goods g=new Goods();
//        g.setGoodsId(2);
//        g.setGoodsInTime(date);
//        g.setGoodsName("西红柿");
//        g.setGoodsNum(20);
//        g.setGoodsSource("业主送的");
//
//        if(adminService.ChangeGoods(g)) {
//    		System.out.println("ChangeGoods Success!");
//    	}
//    	else {
//    		System.out.println("ChangeGoods Defeat!");
//		}
//    }
//    @Test
//    public void Test6(){
//    	//查询一个物品测试
//    	Goods g=adminService.FindGoodsOne(3);
//    	if(g==null) {
//        	System.out.println("No goods!");
//        }
//        else {
//        	System.out.println(g);
//		}
//    }
//    @Test
//    public void Test7(){
//    	//查询所有物品测试
//    	List<Goods> g=adminService.FindGoodsAll();
//    	if(g==null) {
//        	System.out.println("No goods!");
//        }
//        else {
//        	System.out.println(g);
//		}
//    }
//    @Test
//    public void Test8(){
//    	//查询一个用户信息测试
//    	Users u=adminService.FindUserOne(55);
//    	if(u==null) {
//        	System.out.println("No user!");
//        }
//        else {
//        	System.out.println(u);
//		}
//    }
//    @Test
//    public void Test9(){
//    	//查询所有用户信息测试
//    	List<Users> u=adminService.FindUserAll();
//    	if(u==null) {
//        	System.out.println("No users!");
//        }
//        else {
//        	System.out.println(u);
//		}
//    }
//    @Test
//    public void Test10(){
//    	//修改用户信息测试
//    	Users u= new Users();
//    	u.setUserAge(52);
//    	u.setUserId(54);
//    	u.setUserPW("111111");
//    	u.setUserName("周文武");
//    	u.setUserSex("男");
//    	u.setUserIdCard("130903198202257116");
//    	u.setUserPhone(11111111164L);
//    	if(adminService.ChangeUser(u)!=0) {
//    		System.out.println("ChangeUser Success!");
//    	}
//    	else {
//    		System.out.println("ChangeUser Defeat!");
//		}
//    }
//    @Test
//    public void Test11(){
//    	//修改用户密码测试
//    	Manager m= new Manager();
//    	m.setAdminId(1);
//    	m.setAdminPW("123456");
//    	if(adminService.ChangePassword(m, 53, "333333")) {
//    		System.out.println("ChangePassword Success!");
//    	}
//    	else {
//    		System.out.println("ChangePassword Defeat!");
//		}
//    }
//    @Test
//    public void Test12(){
//    	//添加报表测试
//    	Report r=new Report();
//        r.setUserId(52);
//        r.setTemperature("36.5");
//        r.setInTime(null);
//        r.setOutTime(new Date());
//        if(adminService.AddReport(r)!=0) {
//    		System.out.println("AddReport Success!");
//    	}
//    	else {
//    		System.out.println("AddReport Defeat!");
//		}
//    }
//    @Test
//    public void Test13(){
//    	//删除报表测试
//    	if(adminService.DeleteReport(12)!=0) {
//    		System.out.println("DeleteReport Success!");
//    	}
//    	else {
//    		System.out.println("DeleteReport Defeat!");
//		}
//    }
//    @Test
//    public void Test14(){
//    	//查询一个用户报表信息测试
//    	List<Report> r=adminService.FindReportOne(40);
//    	if(r==null) {
//        	System.out.println("No reports!");
//        }
//        else {
//        	System.out.println(r);
//		}
//    }
//    @Test
//    public void Test15(){
//    	//查询所有报表信息测试
//    	List<Report> r=adminService.FindReportAll();
//    	if(r==null) {
//        	System.out.println("No reportlist!");
//        }
//        else {
//        	System.out.println(r);
//		}
//    }
//    @Test
//    public void Test16(){
//    	//查询序列号测试
//    	map.put(1,111111);
//    	map.put(2,222222);
//    	map.put(3,333333);
//    	Collection<Integer> values = map.values();
//    	if(adminService.FindNumber(map, 222222)) {
//    		values.remove(222222);
//    	}
//    	System.out.println(map);
//    }
//    @Test
//    public void Test17(){
//    	//查询报表测试
//
//    }
//}
