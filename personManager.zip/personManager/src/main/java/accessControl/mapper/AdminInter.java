package accessControl.mapper;

import accessControl.pojo.Manager;
import org.apache.ibatis.annotations.Param;

public interface AdminInter {
    //查询一个管理员
    Manager SelectOne(@Param("adminId")int adminId);
}
