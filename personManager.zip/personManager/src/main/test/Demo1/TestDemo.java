//package Demo1;
//
//import accessControl.mapper.AdminInter;
//import accessControl.mapper.GoodsInter;
//import accessControl.mapper.ReportInter;
//import accessControl.mapper.UserInter;
//import accessControl.pojo.Goods;
//import accessControl.pojo.Manager;
//import accessControl.pojo.Report;
//import accessControl.pojo.Users;
//import accessControl.service.UserService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import java.util.Date;
//import java.util.List;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("classpath:spring.xml")
//public class TestDemo {
//    @Autowired
//    UserInter userInter;
//    @Autowired
//    AdminInter adminInter;
//    @Autowired
//    GoodsInter goodsInter;
//    @Autowired
//    ReportInter reportInter;
//    @Autowired
//    UserService userService;
//    //userInter
//    @Test
//    public void Test2(){
//        //SelectOne
////        System.out.println(userInter);
////        Users u=userInter.SelectOne(14);
////        System.out.println(u);
//        //InsertUser
////        Users u= new Users();
////        u.setUserAge(56);
////        u.setUserId(61);
////        u.setUserName("张三");
////        u.setUserSex("男");
////        u.setUserIdCard("430601197702146789");
////        u.setUserPW("456555");
////        u.setUserPhone(11111115124L);
////        int t=userInter.InsertUser(u);
////        System.out.println(t);
//        //UpdateUser
////        Users u= new Users();
////        u.setUserAge(88);
////        u.setUserId(61);
////        u.setUserName("李四");
////        u.setUserSex("女");
////        u.setUserIdCard("430601197702146789");
////        u.setUserPW("789888");
////        u.setUserPhone(11111115124L);
////        int t=userInter.UpdateUser(u);
////        System.out.println(t);
//        //SelectUsers
//        List<Users> users=userInter.SelectUsers();
//        for(Users u: users){
//            System.out.println(u);
//        }
//        //DeleteUser
////        int t=userInter.DeleteUser(61);
////        System.out.println(t);
//    }
//    //AdminInter
//    @Test
//    public void Test3(){
//        Manager manager =adminInter.SelectOne(666666);
//        System.out.println(manager);
//    }
//    //GoodsInter
//    @Test
//    public void Test4(){
//        //SelectOne
////        Goods g=goodsInter.SelectOne(2);
////        System.out.println(g);
//        //InsertGoods
////        Goods g=new Goods();
////        g.setGoodsId(6);
////        g.setGoodsName("玉米");
////        g.setGoodsNum(50);
////        g.setGoodsSource("自己买的");
////        g.setGoodsInTime(new Date());
////        int t=goodsInter.InsertGoods(g);
////        System.out.println(t);
//        //UpdateGoods
////        Goods g=goodsInter.SelectOne(6);
////        g.setGoodsName("娃娃");
////        g.setGoodsNum(56);
////        g.setGoodsSource("超市抢的");
////        g.setGoodsOutTime(new Date());
////        int t=goodsInter.UpdateGoods(g);
////        System.out.println(t);
//        //SelectGoods
////        List<Goods> goods=goodsInter.SelectGoods();
////        for(Goods g:goods){
////            System.out.println(g);
////        }
//        //DeleteGoods
//        int t=goodsInter.DeleteGoods(6);
//        System.out.println(t);
//    }
//    //ReportInter
//    @Test
//    public void Test5(){
//        //SelectOne
////        List<Report> reports=reportInter.SelectOne(40);
////        for(Report r:reports){
////            System.out.println(r);
////        }
//        //InsertReport
////        int num=reportInter.SelectNum();
////        num=num+1;
////        Report r=new Report();
////        r.setOrderNum(num);
////        r.setUserId(40);
////        r.setTemperature("36.6");
////        r.setInTime(new Date());
////        r.setRemarks("为什么回来");
////        int t=reportInter.InsertReport(r);
////        System.out.println(t);
////        //DeleteReport
////        int t=reportInter.DeleteReport(12);
////        System.out.println(t);
//        //SelectReport
////        List<Report> reports=reportInter.SelectReport();
////        for(Report r:reports){
////            System.out.println(r);
////        }
//        //SelectLastReport
//        Report report=reportInter.SelectLastReport(40);
//        System.out.println(report);
//    }
//    @Test
//    public void Tested(){
//    System.out.println(userInter.SelectOne(101223011));
//    }
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
