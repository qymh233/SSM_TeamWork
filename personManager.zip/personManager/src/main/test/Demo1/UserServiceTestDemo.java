//package Demo1;
//
//import accessControl.mapper.GoodsInter;
//import accessControl.pojo.Report;
//import accessControl.pojo.Users;
//import accessControl.service.UserService;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//
//import java.lang.AssertionError;
//
//import java.util.List;
//import java.util.Map;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration("classpath:spring.xml")
//public class UserServiceTestDemo {
//    @Autowired
//    UserService userService;
//    Map<Integer,Integer> map;
//    @Test
//    public void Test1(){
//    	//注册测试
//    	System.out.println(userService);
//    	Users u= new Users();
//    	u.setUserAge(56);
//    	u.setUserId(61);
//    	u.setUserName("张三");
//    	u.setUserSex("男");
//    	u.setUserIdCard("430601197702146789");
//    	u.setUserPW("111111");
//    	u.setUserPhone(11111111171L);
//
//    	if(userService.UserRegister(u)) {
//    		System.out.println("Register Success!");
//    	}
//    	else {
//    		System.out.println("Register Defeat!");
//		}
//    }
//    @Test
//    public void Test2(){
//    	//登录测试
//    	if(userService.UserLogin(30, "111111")) {
//    		System.out.println("Login Success!");
//    	}
//    	else {
//    		System.out.println("Login Defeat!");
//		}
//    }
//    @Test
//    public void Test3(){
//    	//查询用户信息测试
//        Users user=new Users();
//        user=userService.FindUserOne(59);
//        if(user==null) {
//        	System.out.println("No user!");
//        }
//        else {
//        	System.out.println(user);
//		}
//    }
//    @Test
//    public void Test4(){
//    	//修改用户信息测试
//    	Users u= new Users();
//    	u.setUserAge(52);
//    	u.setUserId(58);
//    	u.setUserPW("111111");
//    	u.setUserName("李逍遥");
//    	u.setUserSex("男");
//    	u.setUserIdCard("150703196710018107");
//    	u.setUserPhone(11111111168L);
//    	if(userService.ChangeUser(u)!=0) {
//    		System.out.println("ChangeUser Success!");
//    	}
//    	else {
//    		System.out.println("ChangeUser Defeat!");
//		}
//    }
//    @Test
//    public void Test5(){
//    	//修改密码测试
//    	if(userService.ChangePassword(57, "111111", "222222")) {
//    		System.out.println("ChangePassword Success!");
//    	}
//    	else {
//    		System.out.println("ChangePassword Defeat!");
//		}
//    }
//    @Test
//    public void Test6(){
//    	//生成序列号测试
//    	map.put(56,userService.GetNumber(map));
//    	System.out.println(map);
//    }
//    @Test
//    public void Test7(){
//    	//查询报表测试
//    	Report reports=userService.FindReportOne(40);
//        if(reports==null) {
//        	System.out.println("No reports!");
//        }
//        else {
//        	System.out.println(reports);
//		}
//    }
//    @Test
//    public void Test8(){
//
//    }
//}
