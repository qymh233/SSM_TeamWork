package accessControl.controller;

import accessControl.pojo.Report;
import accessControl.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import accessControl.pojo.Users;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(path = "/User")
public class UserHandler {
    @Autowired
    UserService userService;

    //查询用户信息
    @RequestMapping(path="/findUsesOne")
    public String FindUserOne(@RequestParam(name = "userId") int userId, HttpServletRequest request){

        Users users = userService.FindUserOne(userId);

        if(users == null)
            return "ErrorPage";

        request.setAttribute("user", users);

        return "UserViewPersonalInformationPage";
    }

    //更新时获取用户信息
    @RequestMapping(path="/findUsesOneUpdate")
    public String findUsesOneUpdate(@RequestParam(name = "userId") int userId, HttpServletRequest request){

        Users users = userService.FindUserOne(userId);

        if(users == null)
            return "ErrorPage";

        request.setAttribute("user", users);

        return "UserModifyPersonalInformationPage";
    }

    //修改用户信息
    @RequestMapping(path="/changeUser")
    public String ChangeUser(Users user){

        int numbers = userService.ChangeUser(user);

        if(numbers == 0)
            return "UserModifyPersonalInformationPage";

        return "UserViewPersonalInformationPage";
    }
    //修改用户密码
    @RequestMapping(path="/changePassWord")
    public String ChangePassWord(
            @RequestParam(name = "userId") int userId,
            @RequestParam(name = "userPW") String userPW,
            @RequestParam(name = "newPW") String newPW){

        boolean isChange = userService.ChangePassword(userId, userPW, newPW);

        if(!isChange)
            return "UserChangePasswordPage";

        return "UserLoginPage";
    }
    //用户注册
    @RequestMapping(path="/userRegister", produces="text/html;charset=utf-8")
    @ResponseBody
    public String UserRegister(Users user){

        int id = (int)(Math.random()*1000000000);
        String num = "" + (int)(Math.random()*1000000);

        user.setUserPW(num);
        user.setUserId(id);

        boolean isRegister = userService.UserRegister(user);

        if(!isRegister)
            return "注册失败";

        return "注册成功 您的id为："+ id +",您的初始密码为：" + num;
    }
    //用户登录
    @RequestMapping(path="/userLogin")
    public String UserLogin(@RequestParam(name = "userId") int userId, @RequestParam(name = "userPW") String userPW, HttpSession session){

        boolean isLogin = userService.UserLogin(userId, userPW);
        System.out.println(isLogin);

        if(!isLogin)
            return "UserLoginPage";

        session.setAttribute("userId", userId);

        return "UserMainPage";
    }
    //生成序列号
    @RequestMapping(path="/getNumber", produces="text/html;charset=utf-8")
    @ResponseBody
    public String GetNumber(@RequestParam(name = "userId") int userId, HttpSession session){

        int num = (int)(Math.random()*1000);

        Map<Integer,Integer> map = new HashMap<>();

        map.put(num,userId);

        ServletContext context = session.getServletContext();

        context.setAttribute("map", map);

        return  "您的序列号为："+ num;
    }
    //查询疫情防控信息
    @RequestMapping(path="/releaseInformation")
    public ModelAndView ReleaseInformation(HttpSession session){

        ModelAndView modelAndView = new ModelAndView();

        String information = (String)session.getAttribute("information");

        if(information == null)
            modelAndView.setViewName("ErrorPage");

        modelAndView.setViewName("UserViewEpidemicPreventionInformationPage");
        modelAndView.addObject("information",information);

        return modelAndView;
    }
    //退出controller
    @RequestMapping(path = "/userExit")
    public String toMain(HttpSession session){
        session.removeAttribute("userId");
        return "redirect:/index.jsp";
    }

}
