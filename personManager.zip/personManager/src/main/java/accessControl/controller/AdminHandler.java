package accessControl.controller;

import accessControl.pojo.Goods;
import accessControl.pojo.Manager;
import accessControl.pojo.Report;
import accessControl.pojo.Users;
import accessControl.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;


@Controller
@RequestMapping(path = "/Admin")
public class AdminHandler {

    private static int num = 100;

    @Autowired
    AdminService adminService;
    //管理员登录
    @RequestMapping(path="/adminLogin")
    public String AdminLogin(Manager manager, HttpSession session){

        System.out.println("test登录");

        boolean isLogin = adminService.AdminLogin(manager);

        session.setAttribute("adminId", manager.getAdminId());

        if(!isLogin)
            return "ManagerLoginPage";

        return "ManagerMainPage";
    }
    //管理员签到
    @RequestMapping(path="/adminSignIn", produces="text/html;charset=utf-8")
    @ResponseBody
    public String AdminSignIn(@RequestParam(name = "temperature") String temperature){

        boolean isSignIn = adminService.AdminSignIn(temperature);

        if(!isSignIn)
            return "签到失败";

        return "签到成功";
    }
    //添加物品
    @RequestMapping(path="/addGoods")
    public String AddGoods(Goods goods, HttpSession session) throws ParseException {

        session.setAttribute("addResult", "添加成功");

        String monthStr,dayStr;

        LocalDate localDate = LocalDate.now();

        int month = localDate.getMonthValue();
        if(month < 10){
            monthStr = "0" + month;
        }else{
            monthStr = "" + month;
        }

        int day = localDate.getDayOfMonth();
        if(day < 10){
            dayStr = "0" + day;
        }else{
            dayStr = "" + day;
        }


        String finalDay = "" + localDate.getYear() + "-" + monthStr + "-" + dayStr;

        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = dateformat.parse(finalDay);
        System.out.println(dateformat.format(date));

        goods.setGoodsId(num++);
        goods.setGoodsInTime(date);
        goods.setGoodsInTime(date);

        System.out.println(goods);

        boolean isAdd = adminService.AddGoods(goods);

        if(!isAdd) {
            session.setAttribute("addResult", "添加失败");
            return "redirect:/pages/ManagerMaterialManagementPage.jsp";
        }

        return "redirect:/pages/ManagerMaterialManagementPage.jsp";
    }
    //删除物品
    @RequestMapping(path="/deleteGoods")
    public String DeleteGoods(@RequestParam(name = "goodsId") int goodsId){

        boolean isDelete = adminService.DeleteGoods(goodsId);

        if(!isDelete)
            return "ManagerMaterialManagementPage";

        return "ManagerMaterialManagementPage";
    }
    //修改物品
    @RequestMapping(path="/changeGoods", produces="text/html;charset=utf-8")
    public String ChangeGoods(Goods goods){

        boolean isChange = adminService.ChangeGoods(goods);

        if(!isChange)
            return "redirect:/pages/ErrorPage.jsp";

        return "redirect:/pages/ManagerMaterialManagementPage.jsp";
    }
    //查询一个物品
    @RequestMapping(path="/findGoodsOne")
    public String FindGoodsOne(@RequestParam(name = "goodsId") int goodsId, HttpServletRequest request){

        Goods goods = null;

        goods = adminService.FindGoodsOne(goodsId);

        if(goods == null)
            return "ErrorPage";

        request.setAttribute("good", goods);

        return "ManagerMaterialUpdatePage";
    }
    //查询所有物品
    @RequestMapping(path="/findGoodsAll")
    public String FindGoodsAll(HttpServletRequest request){

        List<Goods> goods;

        goods = adminService.FindGoodsAll();

        if(goods == null)
            return "ErrorPage";

        List<Goods> newGoodsList = new ArrayList<>();

        if(goods.size() > 4) {

            for (int i = 0; i < 4; i++) {
                newGoodsList.add(goods.get(i));
                System.out.println(newGoodsList.get(i));
            }
        }

        request.setAttribute("goods", newGoodsList);

        return "ManagerMaterialInformationDisplayPage";
    }
    //查询一个用户
    @RequestMapping(path="/findUseOne")
    public String FindUserOne(@RequestParam(name = "userId") int userId, HttpServletRequest request){

        Users user = adminService.FindUserOne(userId);

        if(user == null)
            return "ErrorPage";

        request.setAttribute("user", user);

        return "ManagerModifyUserInformationPage";
    }
    //查询所有用户
    @RequestMapping(path="/findUserAll")
    public String FindUserAll(HttpServletRequest request){

        List<Users> users;
        users = adminService.FindUserAll();

        if(users == null)
            return "ErrorPage";

        List<Users> newUsersList = new ArrayList<>();

        if(users.size() > 4){
            for (int i = 0; i < 4; i++) {
                newUsersList.add(users.get(i));
            }
        }

        request.setAttribute("users", newUsersList);

        return "ManagerShowUserListPage";
    }
    //修改用户信息
    @RequestMapping(path="/changeUser", produces="text/html;charset=utf-8")
	@ResponseBody
    public String ChangeUser(Users users){

        int numbers = adminService.ChangeUser(users);

        if(numbers == 0)
            return "ErrorPage";

        return "用户信息修改成功";
    }
    //修改用户密码
    @RequestMapping(path="/changePassword", produces="text/html;charset=utf-8")
    @ResponseBody
    public String ChangePassword(
            Manager manager,
            @RequestParam(name = "userId") int userId,
            @RequestParam(name = "newPW") String newPW){

        boolean isChange = adminService.ChangePassword(manager, userId, newPW);

        if(!isChange)
            return "修改失败";

        return "修改成功";
    }
    //添加报表信息
    @RequestMapping(path="/addReport", produces="text/html;charset=utf-8")
    @ResponseBody
    public String AddReport(@RequestParam("Time") int Time, Report report) throws ParseException {

        String monthStr,dayStr;

        LocalDate localDate = LocalDate.now();

        int month = localDate.getMonthValue();
        if(month < 10){
            monthStr = "0" + month;
        }else{
            monthStr = "" + month;
        }

        int day = localDate.getDayOfMonth();
        if(day < 10){
            dayStr = "0" + day;
        }else{
            dayStr = "" + day;
        }

        String finalDay = "" + localDate.getYear() + "-" + monthStr + "-" + dayStr;

        SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = dateformat.parse(finalDay);
        Date nullDate = dateformat.parse("0000-00-00");
        System.out.println(dateformat.format(date));

        if(Time == 0){
            report.setInTime(date);
            report.setInTime(nullDate);
        }else{
            report.setOutTime(date);
            report.setInTime(nullDate);
        }

        int numbers = adminService.AddReport(report);

        if(numbers == 0)
            return "录入失败";

        return "录入成功";
    }
    //删除报表信息
    @RequestMapping(path="/deleteReport")
    public String DeleteReport(@RequestParam(name = "reportId") int reportId){

        int numbers = adminService.DeleteReport(reportId);

        if(numbers == 0)
            return "deleteReportFail";

        return "deleteReportSuccess";
    }
    //查询报表信息
    @RequestMapping(path="/findReportOne")
    public String FindReportOne(@RequestParam(name = "userId") int userId, HttpServletRequest request){

        List<Report> userList = null;

        userList = adminService.FindReportOne(userId);

        if(userList == null)
            return "findReportOneAdminFail";

        request.setAttribute("userList", userList);

        return "findReportOneAdminSuccess";
    }
    //查询所有报表信息
    @RequestMapping(path="/findReportAll")
    public String FindReportAll(HttpServletRequest request){

        List<Report> userList;

        userList = adminService.FindReportAll();

        if(userList == null)
            return "ErrorPage";

        List<Report> newUserList = new ArrayList<>();

        if(userList.size() > 3){

            for(int i = 0;i < 3;i++){
                newUserList.add(userList.get(i));
            }

        }

        request.setAttribute("userList", newUserList);

        return "ManagerShowReportPage";
    }
    //验证序列号
    @RequestMapping(path="/findNumber", produces="text/html;charset=utf-8")
	@ResponseBody
    public String FindNumber(@RequestParam(name = "serialNum") int serialNum, HttpSession session){

        int userId = 0;

        Map<Integer,Integer> map = (HashMap)session.getServletContext().getAttribute("map");

        if(map != null) {
            userId = map.get(serialNum);
            session.getServletContext().removeAttribute("map");
        }

        return "用户" + userId + "验证成功";
    }
    //TODO 以下三个修改信息格式
    //发布疫情防控信息
    @RequestMapping(path = "/releaseInformation")
    public String ReleaseInformation(@RequestParam(name = "information") String information, HttpSession session){

        session.getServletContext().setAttribute("information", information);

        return "ManagerReleaseInformationPage";
    }
    //防控任务时间通知
    @RequestMapping(path = "/taskTime")
    public String TaskTime(@RequestParam(name = "taskTime") String taskTime, HttpServletRequest request){

        request.setAttribute("taskTime", taskTime);

        return "taskTimeSuccess";
    }
    //防控任务完成情况
    @RequestMapping(path = "/taskCompletion")
    public String TaskCompletion(@RequestParam(name = "taskCompletion") String taskCompletion, HttpServletRequest request){

        request.setAttribute("taskCompletion", taskCompletion);

        return "ManagerRecordPage";
    }

    @RequestMapping(path="/adminExit")
    public String toMain(HttpSession session){

        session.removeAttribute("adminId");

        return "redirect:/index.jsp";
    }
}
